ssh -i ~/athensx -L localhost:8889:localhost:8984 alexpetrov@acropolis.uchicago.edu

python3 iops2_q2.py > output_iops2_q2.txt
